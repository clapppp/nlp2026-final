# 과제 평가를 위해 zip 파일을 만들어 제출합니다.

import os
import zipfile
from pathlib import Path

OUTPUT_DIR = Path("outputs")

PREDICTION_DIRS = [
  Path("outputs/part1_sentiment_classification/predictions"),
  Path("outputs/part2_paraphrase_detection/predictions"),
  Path("outputs/part2_sonnet_generation/predictions"),
]


def existing_required_files():
  for p in os.listdir('.'):
    path = Path(p)
    if path.suffix == '.py':
      yield path, path.as_posix()

  prediction_readme = Path('predictions/README')
  if prediction_readme.exists():
    yield prediction_readme, 'predictions/README'

  seen_prediction_names = set()
  for prediction_dir in PREDICTION_DIRS:
    if not prediction_dir.exists():
      print(f"warning: missing {prediction_dir}")
      continue
    for path in sorted(prediction_dir.iterdir()):
      if path.is_file():
        archive_name = f"predictions/{path.name}"
        if archive_name not in seen_prediction_names:
          seen_prediction_names.add(archive_name)
          yield path, archive_name

  for folder in ('models', 'modules'):
    for path in sorted(Path(folder).iterdir()):
      if path.is_file():
        yield path, path.as_posix()

def main():
  aid = 'nlp2026-final-outputs'
  output_zip = OUTPUT_DIR / f"{aid}.zip"
  output_zip.parent.mkdir(parents=True, exist_ok=True)

  with zipfile.ZipFile(output_zip, 'w') as zz:
    for file, archive_name in existing_required_files():
      zz.write(file, archive_name)
  print(f"Submission zip file created: {output_zip}")

if __name__ == '__main__':
  main()
